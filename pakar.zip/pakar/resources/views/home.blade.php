@extends('master')

@section('content')
Hello world!
@endsection
